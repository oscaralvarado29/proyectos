package proyecto_prueba;

public class prueba {
	public static void main(String[] argumentos){
		System.out.println("Hola mundo");
		}
}
