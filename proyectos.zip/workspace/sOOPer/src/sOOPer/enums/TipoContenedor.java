package sOOPer.enums;

public enum TipoContenedor {
	BOLSA, CAJA;
}
