package sOOPer.enums;

public enum Categoria {
	ALIMENTACION, DROGUERIA, HIGIENE, MASCOTAS;
}
