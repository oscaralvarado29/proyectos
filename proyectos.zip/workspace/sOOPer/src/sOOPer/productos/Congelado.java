package sOOPer.productos;

public class Congelado extends Alimentacion {

	public Congelado(String referencia, int peso, int volumen) {
		super(referencia, peso, volumen);
	}

}
