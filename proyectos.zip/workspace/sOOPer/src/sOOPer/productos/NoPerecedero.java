package sOOPer.productos;

public class NoPerecedero extends Alimentacion {

	public NoPerecedero(String referencia, int peso, int volumen) {
		super(referencia, peso, volumen);
	}

}
