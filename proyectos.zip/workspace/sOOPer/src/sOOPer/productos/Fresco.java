package sOOPer.productos;

public class Fresco extends Alimentacion {

	public Fresco(String referencia, int peso, int volumen) {
		super(referencia, peso, volumen);
	}

}
