package sOOPer;

import java.util.Set;

import sOOPer.enums.TipoContenedor;

public interface IContenedor {
	String getReferencia();
	int getVolumen();
	int volumenDisponible();
	int getResistencia();
	int getSuperficie();
	Set<IProducto> getProductos();
	TipoContenedor getTipo();
	boolean meter(IProducto producto);
	boolean resiste(IProducto producto);

}
