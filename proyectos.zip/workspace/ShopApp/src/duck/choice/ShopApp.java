package duck.choice;

public class ShopApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double tax = 0.2, total=0.0;
		Customer c1 = new Customer("pink");
		Clothing item1 = new Clothing();
		Clothing item2 = new Clothing();
		
		item1.description = "Blue Jacket";
		item1.price = 20.9;
		item2.description = "Orange T-Shirt";
		item2.price = 10.5;
		item2.size = "s";
		System.out.println("Saludo "+c1.getName());
		System.out.println("los detalles de item1 son: ");
		System.out.println("descripcion: " + item1.description);
		System.out.println("precio: " + item1.price);
		System.out.println("talla: " + item1.size);
		System.out.println("los detalles de item2 son: ");
		System.out.println("descripcion: " + item2.description);
		System.out.println("precio: " + item2.price);
		System.out.println("talla: " + item2.size);
		
		total=((2.0*item2.price)+item1.price)*(1.0+tax);
		
		System.out.println("El valor a pagar por " + c1.getName() + " es: "+total);
	}
	

}
