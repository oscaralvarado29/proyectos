package duck.choice;

public class Clothing {
	String description;
	double price;
	String size = "M";
}
