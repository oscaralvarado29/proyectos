package duck.choice;

public class Customer {
	private String name;
	public Customer(String data) {
		this.name = data;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
